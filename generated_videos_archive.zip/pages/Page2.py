from PyQt5.QtWidgets import QWidget, QLabel, QPushButton, QVBoxLayout, QFileDialog, QMessageBox
from PyQt5.QtGui import QPixmap, QPalette, QBrush
import os

class Page2(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Background
        self.set_background("images.jpg")

        self.upload_yml_btn = QPushButton("Upload YML File")
        self.upload_zip_btn = QPushButton("Upload ZIP File")
        self.proceed_btn = QPushButton("Proceed to Interview")
        self.back_btn = QPushButton("Back")
        self.exit_btn = QPushButton("Exit")

        # Button Styling
        for btn in [self.upload_yml_btn, self.upload_zip_btn, self.proceed_btn, self.back_btn, self.exit_btn]:
            btn.setStyleSheet("padding: 10px; font-size: 14px; margin: 5px;")

        # Add widgets
        layout.addWidget(self.upload_yml_btn)
        layout.addWidget(self.upload_zip_btn)
        layout.addWidget(self.proceed_btn)
        layout.addWidget(self.back_btn)
        layout.addWidget(self.exit_btn)

        self.setLayout(layout)

    def set_background(self, image_path):
        if os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            palette = QPalette()
            palette.setBrush(QPalette.Window, QBrush(pixmap.scaled(self.size(), aspectRatioMode=Qt.KeepAspectRatioByExpanding)))
            self.setPalette(palette)
