from .Page1 import Page1
from .Page2 import Page2
