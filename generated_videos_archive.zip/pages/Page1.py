from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt5.QtCore import Qt

class Page1(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        welcome_label = QLabel("Welcome to the Interview Platform")
        welcome_label.setAlignment(Qt.AlignCenter)
        welcome_label.setStyleSheet("font-size: 20px; font-weight: bold;")

        start_button = QPushButton("Start Interview")
        start_button.setStyleSheet("padding: 10px; font-size: 16px;")

        layout.addWidget(welcome_label)
        layout.addWidget(start_button, alignment=Qt.AlignCenter)

        self.setLayout(layout)

        self.start_button = start_button  # Expose for connection
